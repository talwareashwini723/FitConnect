# FitConnect: prototype

Smart Yoga & Fitness Awareness for a Healthier Community (Community Engagement Project).

## Tech stack (as in the presentation)
| Layer | Used here |
|---|---|
| Frontend | HTML, CSS, JavaScript (Jinja templates) |
| Backend | Python, Flask |
| Database | SQLite (file is created automatically; PostgreSQL is a later option) |
| Charts | Chart.js (bundled locally, works offline) |
| Version control | Git / GitHub |

## Features
- **Learn:** yoga library with steps, benefits, cautions and filters, plus a daily tip.
- **Track:** log activity type, minutes and water intake.
- **Dashboard:** weekly chart, 150-min weekly goal, streak.
- **Join:** 7-day community challenge with daily check-ins.
- **Survey:** before / after survey and comparison chart (for measuring impact).

## Run it
```bash
python -m venv venv
venv\Scripts\activate        # Windows   (Mac/Linux: source venv/bin/activate)
pip install -r requirements.txt
python app.py
```
Open http://127.0.0.1:5000, register an account, and explore.

## Git
```bash
git init && git add . && git commit -m "FitConnect prototype"
```

## Project layout
```
app.py            Flask routes + SQLite schema
templates/        HTML pages (Jinja)
static/           CSS, JS, Chart.js, images
instance/         SQLite database (created on first run, git-ignored)
```

## Limits of this prototype
- Built for demonstration: set `SECRET_KEY` as an environment variable for any real use. There is no CSRF protection, email verification or password reset.
- The optional AI pose-feedback module (OpenCV + MediaPipe) is **not** included; it is listed as future scope.
- Yoga content is basic guidance, not medical advice. Have it reviewed by a qualified instructor before real use.
