"""FitConnect prototype: Flask backend + SQLite database (see README.md)."""
import os, sqlite3, datetime as dt
from functools import wraps
from flask import (Flask, g, render_template, request, redirect, url_for,
                   session, flash)
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config["SECRET_KEY"] = os.environ.get("SECRET_KEY", "dev-only-change-me")
os.makedirs(app.instance_path, exist_ok=True)
DB = os.environ.get("FITCONNECT_DB", os.path.join(app.instance_path, "fitconnect.db"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY, name TEXT UNIQUE NOT NULL, pw TEXT NOT NULL,
  challenge_start TEXT);
CREATE TABLE IF NOT EXISTS activities(
  id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL, day TEXT NOT NULL,
  kind TEXT NOT NULL, minutes INTEGER NOT NULL, water INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS checkins(
  user_id INTEGER NOT NULL, day_no INTEGER NOT NULL,
  PRIMARY KEY(user_id, day_no));
CREATE TABLE IF NOT EXISTS survey(
  id INTEGER PRIMARY KEY, user_id INTEGER, phase TEXT NOT NULL,
  screen_hours REAL, exercise_days REAL, yoga_aware INTEGER,
  posture_aware INTEGER, interest INTEGER);
"""

POSES = [
 dict(name="Mountain Pose", sk="Tadasana", tags="posture", emoji="🏔️",
      steps=["Stand with feet hip-width apart.", "Lengthen the spine, relax the shoulders.", "Breathe slowly for 5 breaths."],
      benefit="Improves standing posture and body awareness.",
      caution="Sit down if you feel dizzy."),
 dict(name="Cat-Cow", sk="Marjaryasana-Bitilasana", tags="posture back", emoji="🐈",
      steps=["Start on hands and knees.", "Inhale: drop the belly, lift the chest.", "Exhale: round the back toward the ceiling."],
      benefit="Loosens a stiff back after long sitting.",
      caution="Move gently if you have wrist or knee pain."),
 dict(name="Child's Pose", sk="Balasana", tags="stress back", emoji="🧒",
      steps=["Kneel and sit back on your heels.", "Fold forward, arms stretched ahead.", "Rest and breathe for 30 to 60 seconds."],
      benefit="Calms the mind and stretches the lower back.",
      caution="Place a cushion under the knees if uncomfortable."),
 dict(name="Tree Pose", sk="Vrikshasana", tags="stress posture", emoji="🌳",
      steps=["Stand tall and shift weight to one foot.", "Rest the other foot on the calf or thigh, not the knee.", "Hands to chest, hold 5 breaths, switch sides."],
      benefit="Builds balance and focus.",
      caution="Stand near a wall for support if needed."),
 dict(name="Cobra Pose", sk="Bhujangasana", tags="posture back", emoji="🐍",
      steps=["Lie on your stomach, palms under shoulders.", "Press gently and lift the chest.", "Keep elbows bent, hold 3 to 5 breaths."],
      benefit="Opens the chest, counters hunching over a desk.",
      caution="Avoid deep backbends if you have back injury or are pregnant."),
 dict(name="Seated Forward Bend", sk="Paschimottanasana", tags="stress back", emoji="🧘",
      steps=["Sit with legs stretched forward.", "Inhale tall, exhale and fold from the hips.", "Hold where you feel a mild stretch."],
      benefit="Stretches hamstrings and back, helps relaxation.",
      caution="Bend knees slightly; never force the stretch."),
]
TIPS = [
 "Stand up and stretch for 2 minutes after every hour of sitting.",
 "Keep your screen at eye level to reduce neck strain.",
 "Take a 10-minute walk after a meal.",
 "Drink a glass of water before you start studying.",
 "Five slow deep breaths can reset a stressful moment.",
 "Small daily goals beat big goals you skip.",
 "Roll your shoulders back whenever you notice slouching.",
]
KINDS = ["Yoga", "Walking", "Running", "Stretching", "Cycling", "Gym", "Other"]


def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db


@app.teardown_appcontext
def close_db(_=None):
    d = g.pop("db", None)
    if d:
        d.close()


def init_db():
    c = sqlite3.connect(DB)
    c.executescript(SCHEMA)
    c.commit()
    c.close()


def login_required(f):
    @wraps(f)
    def w(*a, **k):
        if "uid" not in session:
            flash("Please log in first.", "warn")
            return redirect(url_for("login"))
        return f(*a, **k)
    return w


def today():
    return dt.date.today()


# ---------- pages ----------
@app.route("/")
def home():
    d = db()
    stats = dict(
        users=d.execute("SELECT COUNT(*) FROM users").fetchone()[0],
        minutes=d.execute("SELECT COALESCE(SUM(minutes),0) FROM activities").fetchone()[0],
        joined=d.execute("SELECT COUNT(*) FROM users WHERE challenge_start IS NOT NULL").fetchone()[0])
    return render_template("index.html", tip=TIPS[today().toordinal() % len(TIPS)], stats=stats)


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        name, pw = request.form["name"].strip(), request.form["password"]
        if len(name) < 3 or len(pw) < 4:
            flash("Name needs 3+ characters and password 4+.", "warn")
        else:
            try:
                db().execute("INSERT INTO users(name,pw) VALUES(?,?)",
                             (name, generate_password_hash(pw)))
                db().commit()
                flash("Account created. Please log in.", "ok")
                return redirect(url_for("login"))
            except sqlite3.IntegrityError:
                flash("That name is taken.", "warn")
    return render_template("auth.html", mode="register")


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        u = db().execute("SELECT * FROM users WHERE name=?", (request.form["name"].strip(),)).fetchone()
        if u and check_password_hash(u["pw"], request.form["password"]):
            session["uid"], session["name"] = u["id"], u["name"]
            return redirect(url_for("dashboard"))
        flash("Wrong name or password.", "warn")
    return render_template("auth.html", mode="login")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))


@app.route("/learn")
def learn():
    return render_template("learn.html", poses=POSES)


@app.route("/track", methods=["GET", "POST"])
@login_required
def track():
    d = db()
    if request.method == "POST":
        try:
            mins = int(request.form["minutes"]); water = int(request.form.get("water") or 0)
            day = dt.date.fromisoformat(request.form["day"])
            assert 1 <= mins <= 600 and 0 <= water <= 30 and day <= today()
            assert request.form["kind"] in KINDS
        except (ValueError, AssertionError, KeyError):
            flash("Please check the values entered.", "warn")
        else:
            d.execute("INSERT INTO activities(user_id,day,kind,minutes,water) VALUES(?,?,?,?,?)",
                      (session["uid"], day.isoformat(), request.form["kind"], mins, water))
            d.commit()
            flash("Activity saved. Nice work!", "ok")
        return redirect(url_for("track"))
    rows = d.execute("SELECT * FROM activities WHERE user_id=? ORDER BY day DESC, id DESC LIMIT 10",
                     (session["uid"],)).fetchall()
    return render_template("track.html", rows=rows, kinds=KINDS, today=today().isoformat())


@app.route("/track/delete/<int:aid>", methods=["POST"])
@login_required
def delete_activity(aid):
    db().execute("DELETE FROM activities WHERE id=? AND user_id=?", (aid, session["uid"]))
    db().commit()
    return redirect(url_for("track"))


def streak(days):
    s, cur = 0, today()
    if cur.isoformat() not in days:
        cur -= dt.timedelta(days=1)
    while cur.isoformat() in days:
        s, cur = s + 1, cur - dt.timedelta(days=1)
    return s


@app.route("/dashboard")
@login_required
def dashboard():
    d, uid = db(), session["uid"]
    week = [(today() - dt.timedelta(days=i)) for i in range(6, -1, -1)]
    first = week[0].isoformat()
    per = {r["day"]: (r["m"], r["w"]) for r in d.execute(
        "SELECT day, SUM(minutes) m, SUM(water) w FROM activities WHERE user_id=? AND day>=? GROUP BY day",
        (uid, first))}
    alldays = {r[0] for r in d.execute("SELECT DISTINCT day FROM activities WHERE user_id=?", (uid,))}
    mins = [per.get(x.isoformat(), (0, 0))[0] for x in week]
    water = [per.get(x.isoformat(), (0, 0))[1] for x in week]
    total = sum(mins)
    return render_template("dashboard.html", labels=[x.strftime("%a") for x in week],
                           mins=mins, water=water, total=total,
                           pct=min(100, round(total / 150 * 100)),
                           streak=streak(alldays), active=sum(1 for m in mins if m))


@app.route("/challenge")
@login_required
def challenge():
    d, uid = db(), session["uid"]
    start = d.execute("SELECT challenge_start FROM users WHERE id=?", (uid,)).fetchone()[0]
    cur, done = 0, set()
    if start:
        cur = (today() - dt.date.fromisoformat(start)).days + 1
        done = {r[0] for r in d.execute("SELECT day_no FROM checkins WHERE user_id=?", (uid,))}
    comm = dict(
        joined=d.execute("SELECT COUNT(*) FROM users WHERE challenge_start IS NOT NULL").fetchone()[0],
        checks=d.execute("SELECT COUNT(*) FROM checkins").fetchone()[0])
    tasks = ["5 min Mountain + Cat-Cow", "10 min walk", "Child's Pose, 1 minute", "Tree Pose both sides",
             "15 min activity of your choice", "Cobra Pose + water goal", "Share your routine with a friend"]
    return render_template("challenge.html", start=start, cur=cur, done=done, comm=comm, tasks=tasks)


@app.route("/challenge/join", methods=["POST"])
@login_required
def join():
    db().execute("UPDATE users SET challenge_start=? WHERE id=? AND challenge_start IS NULL",
                 (today().isoformat(), session["uid"]))
    db().commit()
    return redirect(url_for("challenge"))


@app.route("/challenge/checkin/<int:n>", methods=["POST"])
@login_required
def checkin(n):
    start = db().execute("SELECT challenge_start FROM users WHERE id=?", (session["uid"],)).fetchone()[0]
    if start and 1 <= n <= min(7, (today() - dt.date.fromisoformat(start)).days + 1):
        db().execute("INSERT OR IGNORE INTO checkins VALUES(?,?)", (session["uid"], n))
        db().commit()
    return redirect(url_for("challenge"))


@app.route("/survey", methods=["GET", "POST"])
@login_required
def survey():
    d = db()
    if request.method == "POST":
        try:
            v = (request.form["phase"], float(request.form["screen_hours"]), float(request.form["exercise_days"]),
                 int(request.form["yoga_aware"]), int(request.form["posture_aware"]), int(request.form["interest"]))
            assert v[0] in ("before", "after") and 0 <= v[1] <= 24 and 0 <= v[2] <= 7
            assert all(1 <= x <= 5 for x in v[3:])
        except (ValueError, AssertionError, KeyError):
            flash("Please check the answers.", "warn")
        else:
            d.execute("INSERT INTO survey(user_id,phase,screen_hours,exercise_days,yoga_aware,posture_aware,interest) "
                      "VALUES(?,?,?,?,?,?,?)", (session["uid"],) + v)
            d.commit()
            flash("Thanks! Response recorded.", "ok")
        return redirect(url_for("survey"))
    cols = ["screen_hours", "exercise_days", "yoga_aware", "posture_aware", "interest"]
    res = {}
    for ph in ("before", "after"):
        r = d.execute("SELECT COUNT(*) n, " + ",".join(f"AVG({c}) {c}" for c in cols) +
                      " FROM survey WHERE phase=?", (ph,)).fetchone()
        res[ph] = dict(n=r["n"], vals=[round(r[c], 2) if r[c] is not None else 0 for c in cols])
    return render_template("survey.html", res=res)


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
else:
    init_db()
