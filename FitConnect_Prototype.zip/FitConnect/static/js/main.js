// Yoga library filter (progressive enhancement)
document.querySelectorAll('[data-filter]').forEach(function (b) {
  b.addEventListener('click', function () {
    var f = b.dataset.filter;
    document.querySelectorAll('[data-filter]').forEach(function (x) { x.classList.toggle('on', x === b); });
    document.querySelectorAll('.pose').forEach(function (p) {
      p.style.display = (f === 'all' || p.dataset.tags.split(' ').indexOf(f) > -1) ? '' : 'none';
    });
  });
});
